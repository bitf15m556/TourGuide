﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Guide.Models;
using System.Diagnostics;


namespace TGuide.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            return View();
        }
        
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Login(string userName, string Password)
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                var details = context.Users.Where(x => x.username.Equals(userName) && x.password.Equals(Password)).SingleOrDefault();

                if (details != null)
                {
                    return View("Main");
                }
                else
                {
                    ViewBag.Message = "Invalid UserName and Password";
                }
            }

            return View();

        }


        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }


        public ActionResult Register(string userName, string pass, string email)
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                User register = new User();

                register.username = userName;
                register.password = pass;
                register.email = email;

                context.Users.Add(register);
                context.SaveChanges();
                ViewBag.Message = "Registeration Successfully";

            }

            return View();
        }
        public ActionResult User()
        {
            return View();
        }
        public ActionResult Suggest()
        {
            return View();
        }
        public ActionResult Suggestions()
        {
            return View();
        }
        public ActionResult Favorites()
        {
            return View();
        }
        public ActionResult History()
        {
            return View();
        }
        public ActionResult Guide1()
        {
            return View();
        }

        // GET: /Admin/
        public ActionResult Main()
        {
            return View();
        }

        public ActionResult Places()
        {
            using (TGDBEntities context=new TGDBEntities())
            {

                IEnumerable<place> p=context.places.ToList();
                return View(p);
            }
            
        }

        [HttpGet]
        public ActionResult Add()
        {
            return View();
        }

        public ActionResult Add(string cntry, string cty, string ttype, string htl, int cst)
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                place plc = new place();

                plc.country = cntry;
                plc.city = cty;
                plc.tour_type = ttype;
                plc.hotel = htl;
                plc.cost = cst;

                context.places.Add(plc);
                context.SaveChanges();
                ViewBag.Message = "Successfully Added";

            }

            return View();
        }


        [HttpGet]
        public ActionResult Remove()
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                IEnumerable<place> p=context.places.ToList();
                return View(p);
            }
           
        }

        public ActionResult Remove12(int Id)
        {
            using (TGDBEntities context = new TGDBEntities())
            {

                place data=context.places.Find(Id);
                context.places.Remove(data);
                context.SaveChanges();
            }
            return View("Add");
        }

        [HttpGet]
        public ActionResult Edit()
        {
            return View();
        }
        public ActionResult Edit(string ttype, int id)
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                var details = context.places.Where(x => x.tour_type.Equals(ttype) && x.Id.Equals(id)).SingleOrDefault();

                if (details != null)
                {
                    Session["xValue"] = id;

                    //Redirect to your other page after storing your value
                    Response.Redirect("GoEdit");
                    //return View("GoEdit");
                }
                else
                {
                    ViewBag.Message = "Place not found";
                }
            }
            return View();
        }

        [HttpGet]
        public ActionResult GoEdit()
        {
            //This would be retrieved in your YourTargetPage.cshtml file using the following code
            if (Session["xValue"] != null)
            {
                //Grab your value if it exists
                var pValue = Session["xValue"];
                ViewBag.val = pValue;
            }
            
            return View();
        }

        public ActionResult GoEdit(int id,string ttype,string cntry,string cty,int cst,string htl)
        {
            using (TGDBEntities context = new TGDBEntities())
            {
                
                place plc = context.places.Where(x => x.Id.Equals(id) && x.tour_type.Equals(ttype)).SingleOrDefault();
                plc.Id = id;
                plc.tour_type = ttype;
                plc.country = cntry;
                plc.city = cty;
                plc.cost = cst;
                plc.hotel = htl;

                context.SaveChanges();
                ViewBag.Message = "Successfully Updated";

            }

            return View();
        }
    }
}
